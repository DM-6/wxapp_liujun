const goods = [
  {
    id: 1,
    image: '/images/goods1.png',
    title: '新鲜梨花带雨',
    price: 0.01,
    stock: '有货',
    detail: '这里是梨花带雨详情',
    service: '不支持退货',
    parameter: '125g/个'
  },
  {
    id: 2,
    image: '/images/goods1.png',
    title: '新鲜梨花带雨222',
    price: 0.01,
    stock: '有货',
    detail: '这里是梨花带雨详情',
    service: '不支持退货',
    parameter: '125g/个'
  }
]

export default goods;